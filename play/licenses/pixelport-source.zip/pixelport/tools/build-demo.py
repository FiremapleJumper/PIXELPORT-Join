"""Build PixelPort's original NES controller demo. No game assets required."""
from pathlib import Path
import struct

root=Path(__file__).resolve().parents[1]
code=bytearray();labels={};fixups=[]
def emit(*b):code.extend(b)
def label(name):labels[name]=0x8000+len(code)
def word(op,address):emit(op,address&255,address>>8)
def jump(op,name):emit(op,0,0);fixups.append(('word',len(code)-2,name))
def branch(op,name):emit(op,0);fixups.append(('rel',len(code)-1,name))
def lda(n):emit(0xa9,n)
def sta(a):word(0x8d,a)
def addr(a):lda(a>>8);sta(0x2006);lda(a&255);sta(0x2006)

font={
'A':['01110','10001','10001','11111','10001','10001','10001'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'D':['11110','10001','10001','10001','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'1':['010','110','010','010','010','010','111'],
'2':['01110','10001','00001','00110','01000','10000','11111'],
'J':['00111','00010','00010','00010','10010','10010','01100'],
'K':['10001','10010','10100','11000','10100','10010','10001'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'I':['111','010','010','010','010','010','111'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','10101','10011','10001','10001','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'V':['10001','10001','10001','10001','10001','01010','00100'],
'W':['10001','10001','10001','10101','10101','11011','10001'],
'X':['10001','10001','01010','00100','01010','10001','10001'],
'Y':['10001','10001','01010','00100','00100','00100','00100'],
}
tiles={c:i+2 for i,c in enumerate(font)}
def text(a,s):
 addr(a)
 for c in s:lda(tiles.get(c,0));sta(0x2007)

label('reset');emit(0x78,0xd8,0xa2,0x40);word(0x8e,0x4017);emit(0xa2,0xff,0x9a,0xe8)
for a in [0x2000,0x2001,0x4010]:word(0x8e,a)
label('wait1');word(0x2c,0x2002);branch(0x10,'wait1')
lda(0);emit(0xa2,0)
label('clear')
for page in range(8):word(0x9d,page*256)
emit(0xe8);branch(0xd0,'clear')
lda(0xff);emit(0xa2,0);label('sprites');word(0x9d,0x0200);emit(0xe8);branch(0xd0,'sprites')
label('wait2');word(0x2c,0x2002);branch(0x10,'wait2')
addr(0x2000);lda(0);emit(0xa0,4,0xa2,0)
label('nametable');sta(0x2007);emit(0xe8);branch(0xd0,'nametable');emit(0x88);branch(0xd0,'nametable')
addr(0x3f00)
for n in [0x0f,0x30,0x21,0x31]*4+[0x0f,0x28,0x30,0x16]+[0x0f,0x16,0x30,0x28]*3:lda(n);sta(0x2007)
text(0x20eB,'PIXELPORT');text(0x2148,'CONTROLLER DEMO');text(0x22c7,'P1 ARROWS P2 IJKL');text(0x2307,'X COLOR F COLOR')
lda(120);sta(0x0200);lda(1);sta(0x0201);lda(0);sta(0x0202);lda(96);sta(0x0203)
lda(120);sta(0x0204);lda(1);sta(0x0205);sta(0x0206);lda(152);sta(0x0207)
lda(0x80);sta(0x2000);lda(0x1e);sta(0x2001)
label('loop');jump(0x4c,'loop')
label('nmi');emit(0x48,0x8a,0x48,0x98,0x48)
lda(1);sta(0x4016);lda(0);sta(0x4016);emit(0x85,0,0x85,1,0xa2,8)
label('pad');word(0xad,0x4016);emit(0x4a,0x26,0);word(0xad,0x4017);emit(0x4a,0x26,1,0xca);branch(0xd0,'pad')
for mask,a,opcode,name in [(1,0x0203,0xee,'right'),(2,0x0203,0xce,'left'),(4,0x0200,0xee,'down'),(8,0x0200,0xce,'up')]:
 emit(0xa5,0,0x29,mask);branch(0xf0,'skip_'+name);word(opcode,a);label('skip_'+name)
emit(0xa5,0,0x29,0x80);branch(0xf0,'normal');lda(1);jump(0x4c,'attribute');label('normal');lda(0);label('attribute');sta(0x0202)
for mask,a,opcode,name in [(1,0x0207,0xee,'right2'),(2,0x0207,0xce,'left2'),(4,0x0204,0xee,'down2'),(8,0x0204,0xce,'up2')]:
 emit(0xa5,1,0x29,mask);branch(0xf0,'skip_'+name);word(opcode,a);label('skip_'+name)
lda(0);sta(0x2003);lda(2);sta(0x4014);lda(0);sta(0x2005);sta(0x2005)
emit(0x68,0xa8,0x68,0xaa,0x68,0x40)
label('irq');emit(0x40)
for kind,i,name in fixups:
 a=labels[name]
 if kind=='word':code[i:i+2]=struct.pack('<H',a)
 else:
  delta=a-(0x8000+i+1)
  assert -128<=delta<=127,(name,delta)
  code[i]=delta&255
prg=code+bytes(16384-len(code));prg[-6:]=struct.pack('<HHH',labels['nmi'],labels['reset'],labels['irq'])
chrdata=bytearray(8192)
star=[0x18,0x3c,0x7e,0xff,0x7e,0x3c,0x18,0]
chrdata[16:24]=bytes(star)
for c,rows in font.items():
 offset=tiles[c]*16
 for y,row in enumerate(rows):chrdata[offset+y]=int(row,2)<<(7-len(row))
path=root/'dist/demo/pixelport-controller.nes';path.parent.mkdir(exist_ok=True)
path.write_bytes(b'NES\x1a'+bytes([1,1,0,0])+bytes(8)+prg+chrdata)
print(f'Built {path.name}: {path.stat().st_size} bytes')
