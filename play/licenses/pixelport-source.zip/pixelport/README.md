# PixelPort

A browser Nintendo emulator hub with friend invite rooms. Load local game files; they are not uploaded.

- NES: JSNES 2.1.0 with Canvas 2D; FCEUmm compatibility core for archives/disk games.
- SNES, N64, Game Boy, Game Boy Color, GBA, DS and Virtual Boy: EmulatorJS 4.2.3.
- 3DS: experimental Azahar nightly core; requires WebGL 2, shared memory and threads. No 3DS wireless multiplayer.
- GameCube/Wii: bundled experimental wasm-dolphin with an unchanged core.
- Wii Remote, pointer and motion input are not implemented in the browser core.
- Disc playback needs cross-origin isolation, WebGPU and a desktop Chromium browser.
- An original NES controller demo is included. Build its ROM with `python tools/build-demo.py`.

## Development

Static assets are in `dist/`. Serve over HTTP(S); do not open the HTML with file://.
Serve the headers in `dist/_headers`; the service worker provides a fallback for static hosts.
Run `npm run check` for JavaScript syntax checks.

The source manifest `.openai/hosting.json` identifies the hosted Site.

## Licenses

PixelPort frontend: GPL-3.0-or-later. Dolphin-derived host files: GPL-2.0-or-later.
All modified Dolphin files are included in the downloadable source.
The bundled core's verified complete corresponding source is provided as downloadable,
a separate, owner-accessible source archive linked from `dist/licenses/source-download.html`.

The core is from dougchansan/wasm-dolphin, based on pinned Dolphin upstream commit
`e22551eae1c84a7e4d0b6a5c519ef4ed4ef69df1` and its verified 66-patch source lock.

No commercial games or Nintendo BIOS files are included.

## Online rooms (beta)

Start a NES, SNES or N64 couch-multiplayer game and choose Online rooms → Host game.
The host runs the emulator and shares its canvas video and available game audio.
One guest joins by room code and sends Player 2 controller states over a WebRTC data
channel. No ROM bytes are sent. PeerJS Cloud handles signaling; its default ICE
servers handle connection traversal. Restricted networks can prevent a connection.
Room creation and peer discovery were verified; live video/data gameplay could not
be verified in the test browser, where connection negotiation timed out.

`dist/pixelport-guest.html` is a standalone guest client containing its scripts.
The owner can download and send that file to a friend without changing Site access.
Generate it with `python tools/build-guest.py`. No microphone/camera API is used.
Closing a connection releases Player 2 input; host input has a heartbeat timeout.

Local NES/SNES two-player controls and N64 gamepad slots are also configured.
Run `node --test tests/multiplayer.test.mjs` for controller/protocol checks.

## Mod ZIP export

Choose Mod ZIPs, select your original game and an extracted IPS/BPS patch, then download the patched-game ZIP or a patch-only kit. Processing runs in a local Worker; no ROMs or patches are uploaded. BPS validates source, target and patch checksums. IPS has no source checksum. A 45-second timeout cancels stuck parsing. Limits: 128 MiB base, 32 MiB patch, 256 MiB output.

Three patch-only built-ins are offered in game/mod dropdowns: Kaze SM64 split-screen (Final), Takoshero OoT split-screen v0.8, and ErikHK SMB3 simultaneous v2. Attribution, pinned checksums and requirements are in `dist/mod-catalog.js` and `dist/mods/ATTRIBUTION.txt`. Built-ins enforce base size/CRC and patch integrity before applying. No original game ROMs are included. Gameplay is experimental and unverified. Patches must already support multiplayer and the chosen emulator. Browser rooms send one guest to controller 2; this does not add multiplayer to a single-player game. Zelda64 Online needs desktop ModLoader64; SM64 Coop DX is a desktop port. Neither is a browser ROM mod.

Run `node --test tests/patcher.test.cjs` for patch/export validation.
