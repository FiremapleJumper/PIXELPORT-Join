# PixelPort source

The published GitHub Pages app is under play/. Serve play/ with a local static web server for the frontend. The app downloads EmulatorJS cores; the Dolphin WASM binaries are available from the public deployed site and excluded from this source-only ZIP. Full Dolphin corresponding source, dependencies and build tools are attached to the public GitHub release linked from play/licenses/source-download.html. Native Wii input changes, tests and build instructions are in native/wii/. No commercial games are included.
