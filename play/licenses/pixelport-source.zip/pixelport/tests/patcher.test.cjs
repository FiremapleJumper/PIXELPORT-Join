const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {File}=require('node:buffer');
const root=path.resolve(__dirname,'../dist');
function runtime(){
 const context=vm.createContext({ArrayBuffer,Uint8Array,Uint32Array,DataView,TextEncoder,TextDecoder,Blob,File,console});
 context.self=context;
 context.importScripts=(...files)=>files.forEach(file=>vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context,{filename:file}));
 vm.runInContext(fs.readFileSync(path.join(root,'patch-worker.js'),'utf8'),context);
 return context;
}
async function apply(context,rom,patch,preset){let result;context.postMessage=data=>{result=data};await context.onmessage({data:{rom,patch,preset}});return result}
test('BPS export validates the base and builds a patched game and ROM-free patch kit',async()=>{
 const c=runtime();
 const original=Uint8Array.from({length:64},(_,i)=>i);original[4]=10;
 const modified=original.slice();modified[4]=99;
 c.original=original;c.modified=modified;
 const bytes=vm.runInContext('BPS.buildFromRoms(new BinFile(original),new BinFile(modified)).export()._u8array',c);
 const patch=new File([bytes],'multiplayer.bps');
 const result=await apply(c,new File([original],'game.z64'),patch);
 assert.equal(result.ok,true,result.error);
 assert.deepEqual(new Uint8Array(result.rom),modified);
 c.zip=new Uint8Array(result.zip);c.kit=new Uint8Array(result.kit);
 const game=vm.runInContext('fflate.unzipSync(zip)',c),kit=vm.runInContext('fflate.unzipSync(kit)',c);
 assert.deepEqual(game['game-modded.z64'],modified);
 assert.deepEqual(kit['multiplayer.bps'],bytes);
 assert.equal(Object.keys(kit).some(name=>name.endsWith('.z64')),false);
 assert.ok(game['README.txt']);assert.ok(kit['patch-info.json']);
 original[2]^=1;
 const invalid=await apply(c,new File([original],'wrong.z64'),patch);
 assert.equal(invalid.ok,false);assert.match(invalid.error,/checksum/i);
 bytes[bytes.length-1]^=1;
 const corrupt=await apply(c,new File([modified],'game.z64'),new File([bytes],'corrupt.bps'));
 assert.equal(corrupt.ok,false);assert.match(corrupt.error,/checksum/i);
});
test('IPS changes the intended byte and unsupported archives are rejected',async()=>{
 const c=runtime(),original=new Uint8Array(64);
 const bytes=Uint8Array.from([80,65,84,67,72,0,0,4,0,1,42,69,79,70]);
 const result=await apply(c,new File([original],'game.z64'),new File([bytes],'mod.ips'));
 assert.equal(result.ok,true,result.error);assert.equal(new Uint8Array(result.rom)[4],42);
 assert.match(result.manifest.validation,/no source checksum/i);
 const unsupported=await apply(c,new File([original],'game.z64'),new File(['PK00'],'pack.zip'));
 assert.equal(unsupported.ok,false);assert.match(unsupported.error,/Unsupported patch/);
});

test('built-in catalog files match pinned hashes and BPS base requirements',async()=>{
 const {BUILTIN_MODS,modsForGame,MOD_GAMES}=await import('../dist/mod-catalog.js');
 const crypto=require('node:crypto');
 assert.equal(BUILTIN_MODS.length,3);
 for(const game of MOD_GAMES.filter(game=>game.id!=='other'))assert.equal(modsForGame(game.id).length,1);
 const c=runtime();
 for(const mod of BUILTIN_MODS){
  const bytes=fs.readFileSync(path.join(root,mod.file));
  assert.equal(crypto.createHash('md5').update(bytes).digest('hex'),mod.patchMD5);
  c.bytes=new Uint8Array(bytes);
  if(mod.file.endsWith('.bps')){
   const parsed=vm.runInContext('BPS.fromFile(new BinFile(bytes))',c);
   assert.equal(parsed.sourceSize,mod.sourceSize);
   assert.ok(mod.sourceCRC32.includes(parsed.sourceChecksum.toString(16).padStart(8,'0')));
  }
  const mismatch=await apply(c,new File([new Uint8Array(64)],'wrong-game.rom'),new File([bytes],mod.file),mod);
  assert.equal(mismatch.ok,false);assert.match(mismatch.error,/does not match the selected mod/);
 }
});
test('built-in integrity rejection and valid IPS metadata survive ZIP export',async()=>{
 const c=runtime(),crypto=require('node:crypto'),original=new Uint8Array(64);
 const bytes=Uint8Array.from([80,65,84,67,72,0,0,4,0,1,42,69,79,70]);
 c.original=original;
 const preset={id:'fixture',title:'Fixture mod',author:'Test author',source:'https://example.com/mod',base:'Fixture game',sourceSize:64,sourceCRC32:[vm.runInContext('new BinFile(original).hashCRC32().toString(16).padStart(8,"0")',c)],patchMD5:crypto.createHash('md5').update(bytes).digest('hex'),extension:'.nes'};
 const result=await apply(c,new File([original],'base.bin'),new File([bytes],'fixture.ips'),preset);
 assert.equal(result.ok,true,result.error);assert.equal(result.name,'base-modded.nes');
 assert.equal(result.manifest.mod.author,'Test author');assert.match(result.manifest.validation,/Built-in base game checksum/);
 bytes[10]^=1;
 const corrupt=await apply(c,new File([original],'base.bin'),new File([bytes],'fixture.ips'),preset);
 assert.equal(corrupt.ok,false);assert.match(corrupt.error,/integrity check failed/);
});
