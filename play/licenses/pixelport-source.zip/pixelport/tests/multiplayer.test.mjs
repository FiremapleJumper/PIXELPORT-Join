import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {makeInputMux,normalizeState,gamepadState} from '../dist/controller.js';
import {normalizeRoom,newRoom,displayRoom} from '../dist/net-session.js';
import {detectSystem,SYSTEMS} from '../dist/systems.js';
const blank=()=>Array(24).fill(0);

test('room codes round-trip and reject unrelated input',()=>{
 const a=newRoom(),b=newRoom();assert.notEqual(a,b);assert.equal(a.length,24);assert.equal(normalizeRoom(displayRoom(a)),a);assert.equal(normalizeRoom('hello'),null);assert.equal(normalizeRoom('a'.repeat(25)),null);
});
test('remote controller payloads are bounded and malformed payloads rejected',()=>{
 assert.equal(normalizeState([1]),null);assert.equal(normalizeState({length:24}),null);
 const state=blank();state[0]=999;state[1]=-7;state[16]=1e9;state[17]=NaN;assert.deepEqual(normalizeState(state).slice(0,2),[1,0]);assert.equal(normalizeState(state)[16],32767);assert.equal(normalizeState(state)[17],0);
});
test('releasing a source keeps other held input and releases disconnected remote input',()=>{
 const changes=[],mux=makeInputMux(2,(...args)=>changes.push(args)),held=blank();held[0]=1;
 mux.set('keyboard',[held,blank()]);mux.set('gamepad',[held,blank()]);mux.remove('keyboard');assert.equal(changes.length,1);mux.remove('gamepad');assert.deepEqual(changes.at(-1),[1,0,0]);
 mux.set('remote',[blank(),held]);assert.deepEqual(changes.at(-1),[2,0,1]);mux.remove('remote');assert.deepEqual(changes.at(-1),[2,0,0]);
});
test('standard gamepad supports digital and analog movement',()=>{
 const pad={buttons:Array.from({length:16},()=>({pressed:false})),axes:[1,-1,0,0]};pad.buttons[0].pressed=true;
 const state=gamepadState(pad,true);assert.equal(state[0],1);assert.equal(state[7],1);assert.equal(state[4],1);assert.equal(state[16],32767);assert.equal(state[19],32767);
});
test('Player 2 moves independently in the real NES core and stops on disconnect',()=>{
 const sandbox={module:{exports:{}},exports:{}};vm.runInNewContext(fs.readFileSync(new URL('../dist/vendor/jsnes-2.1.0.min.js',import.meta.url),'utf8'),sandbox);
 const {NES}=sandbox.module.exports,nes=new NES({emulateSound:false});nes.loadROM(new Uint8Array(fs.readFileSync(new URL('../dist/demo/pixelport-controller.nes',import.meta.url))));for(let i=0;i<20;i++)nes.frame();
 const x1=nes.cpu.mem[0x203],x2=nes.cpu.mem[0x207],remote=blank();remote[7]=1;
 const mux=makeInputMux(2,(p,b,v)=>{if(b<8)(v?nes.buttonDown:nes.buttonUp)(p,b)});mux.set('remote',[blank(),remote]);for(let i=0;i<10;i++)nes.frame();assert.equal(nes.cpu.mem[0x203],x1);assert.equal(nes.cpu.mem[0x207],x2+10);
 mux.remove('remote');for(let i=0;i<5;i++)nes.frame();assert.equal(nes.cpu.mem[0x207],x2+10);
});
test('3DS has a distinct core and CIA gets a useful error',async()=>{
 assert.equal(SYSTEMS.length,11);const file=name=>new File([new Uint8Array(64)],name);
 for(const name of ['test.3ds','test.cci','test.cxi','test.3dsx'])assert.equal((await detectSystem(file(name))).id,'3ds');
 assert.equal((await detectSystem(file('test.elf'),'3ds')).id,'3ds');await assert.rejects(()=>detectSystem(file('test.cia')),/installation packages/);
});
